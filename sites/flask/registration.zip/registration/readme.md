registration form lesson in coding-dojo's curriculum from Python track
